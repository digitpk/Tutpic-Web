

<table>

    <h1>For Activation User Account </h1>+
    <p>Dear {{$name}}</p>
    <p>Title {{$subject}}</p>
    <hr/>
    <p>{{$remarks}}</p>

</table>
