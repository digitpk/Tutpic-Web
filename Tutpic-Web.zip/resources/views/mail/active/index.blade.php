

<table>
    <h1>For Activation User Account </h1>
    <p>Dear {{$user->name}}</p>
    <p>Thank you for Joining US.</p>
    <hr/>
    <p><b>Click here to active your Account</b></p>

      <a class="btn btn-success" href="{{url($url)}}"> For verification</a>
</table>
