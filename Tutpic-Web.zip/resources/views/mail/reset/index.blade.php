

<table>
    <h1>For Reset User Account Password </h1>
    <hr/>
    <p><b>Click here to reset password</b></p>

      <a class="btn btn-success" href="{{url($url)}}"> click here</a>
</table>
