
<!-- Start Slider Area  -->
<div class="rn-slider-area position-relative" id="home">
    <div id="particles-js"></div>
    <div class="slide slide-style-2 bg_image bg_image--27 d-flex align-items-center justify-content-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner text-center">
                        <h1 class="title theme-gradient">Creative One Page</h1>
                        <p class="description">There are many variations of passages of Lorem Ipsum
                            available but the majority have suffered alteration.</p>
                        <div class="slide-btn">
                            <a class="rn-button-style--2 btn-primary-color" href="contact.html">Contact
                                Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Slider Area  -->
