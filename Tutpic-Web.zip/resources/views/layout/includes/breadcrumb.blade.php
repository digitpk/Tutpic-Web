<div class="breadcrumb-area rn-bg-color ptb--120 bg_image bg_image--1" data-black-overlay="6">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inner pt--100 pt_sm--40 pt_md--50">
                    <h2 class="title">{{$page_title}}</h2>
{{--                    <ul class="page-list">--}}
{{--                        <li><a href="index.html">Home</a></li>--}}
{{--                        <li class="current-page">About</li>--}}
{{--                    </ul>--}}
                </div>
            </div>
        </div>
    </div>
</div>
