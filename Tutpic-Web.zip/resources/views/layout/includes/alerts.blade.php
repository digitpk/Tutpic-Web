
<div style="display: none" id="alert-new-chat" class="alert alert-success alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>New Session!</strong> <a href="#" id="new-chat-link">Click here</a> to join new session
</div>
