<a class="btn btn-lg btn-primary btn-block btn-grad text-uppercase fb"
   type="submit">
    <i class="fab fa-facebook-f"></i> Facebook</a>
