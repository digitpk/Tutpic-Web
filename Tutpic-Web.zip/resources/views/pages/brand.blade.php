<!-- Start Brand Area -->
<div class="rn-brand-area rn-section-gap bg_color--1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul class="brand-style-2">
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-01.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-02.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-03.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-04.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-05.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-06.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-02.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-03.png" alt="Logo Images" />
                    </li>
                    <li>
                        <img src="{{asset('/')}}assets/images/brand/brand-04.png" alt="Logo Images" />
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Brand Area -->
