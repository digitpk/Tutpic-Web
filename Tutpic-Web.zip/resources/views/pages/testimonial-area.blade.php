
<!-- Start Testimonial Area  -->
<div class="rn-testimonial-area rn-section-gap bg_color--5" id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Start Tab Content  -->
                <div class="rn-testimonial-content tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab1-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="tab2-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="tab3-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="tab4-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab5" role="tabpanel" aria-labelledby="tab5-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab6" role="tabpanel" aria-labelledby="tab6-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab7" role="tabpanel" aria-labelledby="tab7-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab8" role="tabpanel" aria-labelledby="tab8-tab">
                        <div class="inner">
                            <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those interested. Sections Bonorum et Malorum original.</p>
                        </div>
                        <div class="author-info">
                            <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                        </div>
                    </div>
                </div>
                <!-- End Tab Content  -->

                <!-- Start Tab Nav  -->
                <ul class="testimonial-thumb-wrapper nav nav-tabs" id="myTab" role="tablist">
                    <li>
                        <a class="active" id="tab1-tab" data-toggle="tab" href="#tab1" role="tab" aria-controls="tab1" aria-selected="true">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-1.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a id="tab2-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="tab2" aria-selected="false">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-2.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a id="tab3-tab" data-toggle="tab" href="#tab3" role="tab" aria-controls="tab3" aria-selected="false">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-3.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a id="tab4-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="tab4" aria-selected="false">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-4.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="tab5-tab" data-toggle="tab" href="#tab5" role="tab" aria-controls="tab5" aria-selected="false">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-5.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="tab6-tab" data-toggle="tab" href="#tab6" role="tab" aria-controls="tab6" aria-selected="false">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-6.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="tab7-tab" data-toggle="tab" href="#tab7" role="tab" aria-controls="tab7" aria-selected="false">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-7.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="tab8-tab" data-toggle="tab" href="#tab8" role="tab" aria-controls="tab8" aria-selected="false">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="{{asset('/')}}assets/images/client/testimonial-8.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>
                </ul>
                <!-- End Tab Content  -->
            </div>
        </div>
    </div>
</div>
<!-- Start Testimonial Area  -->
