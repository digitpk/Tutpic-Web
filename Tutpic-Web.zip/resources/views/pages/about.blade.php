

    <!-- Start About Area  -->
    <div class="about-area rn-section-gap bg_color--5" id="about">
        <div class="about-wrapper">
            <div class="container">
                <div class="row row--35 align-items-center">
                    <div class="col-lg-5 col-md-12">
                        <div class="thumbnail">
                            <img class="w-100" src="{{asset('/')}}assets/images/about/about-3.jpg" alt="About Images" />
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12">
                        <div class="about-inner inner">
                            <div class="section-title">
                                <h2 class="title">About</h2>
                                <p class="description">There are many variations of passages of Lorem Ipsum
                                    available, but the majority have suffered alteration in some form, by
                                    injected humour, or randomised words which dont look even slightly
                                    believable. If you are going to use a passage of Lorem Ipsum,</p>
                            </div>
                            <div class="row mt--30 mt_sm--10">
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="about-us-list">
                                        <h3 class="title">Who we are</h3>
                                        <p>There are many vtions of passages of Lorem Ipsum available, but the
                                            majority have suffered.</p>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="about-us-list">
                                        <h3 class="title">Who we are</h3>
                                        <p>There are many vtions of passages of Lorem Ipsum available, but the
                                            majority have suffered.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Start About Area  -->

