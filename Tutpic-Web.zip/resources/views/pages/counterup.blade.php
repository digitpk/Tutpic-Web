<!-- Start Counterup Area  -->
<div class="rn-counterup-area rn-section-gap bg_color--5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-single-title text-center">
                    <h3 class="fontWeight500">Our Fun Facts</h3>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- Start Single Counterup  -->
            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                <div class="rn-counterup counterup_style--1">
                    <h5 class="counter count">992</h5>
                    <p class="description">The standard chunk of Lorem Ipsum used since the 1500s is
                        reproduced below for those.</p>
                </div>
            </div>
            <!-- Start Single Counterup  -->

            <!-- Start Single Counterup  -->
            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                <div class="rn-counterup counterup_style--1">
                    <h5 class="counter count">575</h5>
                    <p class="description">The standard chunk of Lorem Ipsum used since the 1500s is
                        reproduced below for those.</p>
                </div>
            </div>
            <!-- Start Single Counterup  -->

            <!-- Start Single Counterup  -->
            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                <div class="rn-counterup counterup_style--1">
                    <h5 class="counter count">69</h5>
                    <p class="description">The standard chunk of Lorem Ipsum used since the 1500s is
                        reproduced below for those.</p>
                </div>
            </div>
            <!-- Start Single Counterup  -->
        </div>
    </div>
</div>
<!-- End Counterup Area  -->
