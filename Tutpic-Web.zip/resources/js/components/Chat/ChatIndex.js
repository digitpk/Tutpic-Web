import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export default class ChatIndex extends Component {
    render() {
        return (
            <h1>Chat index</h1>
        );
    }
}

